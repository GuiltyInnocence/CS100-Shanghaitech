#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*******************************Functions******************************/
/* You need to check whether the given `mahjongHand` is win.
 * If wins, return 1, otherwise, return 0
 * The length of `mahjongHand` is guaranteed to be 14.
 * All tiles are guaranteed to be legal.
 */
int CheckWin(char* mahjongHand[])
{
    // YOUR CODE HERE
    return 0;
}

/* You need to count the number of different tiles that
 * lead him to win. 
 * The length of `currentTiles` is guaranteed to be 13,
 * all tiles are guaranteed to be legal. You should ignore 
 * the tiles that are used up (already 4 in his hand). 
 * Return the number of different tiles that leads him to win.
 */
int CountWaitingTiles(char* currentTiles[])
{
    // YOUR CODE HERE
    return -1;
}

/*****************************Your Main Function*************************************/
// DO NOT submit main function to OJ, or compile error may happen!
int main()
{
    /*************** Part1 ***************/
    char* hand[14] = {"1s", "2z", "3m", "5p", "6s", "5p", "3z", "5z", \
                      "4z", "7m", "9s", "9p", "3z", "4s"};
    // char* hand[14] = {"1s", "1s", "1s", "2p", "2p", "2p", "5p", "6p", \
    //                   "7p", "3z", "3z", "9s", "3z", "9s"};
    int result = CheckWin(hand);
    printf ("Gezi Wang %s the game.\n", result == 1 ? "wins" : "does not win");

    /*************** Part2 ***************/
    // char* hand[13] = {"1s", "1s", "1s", "2s", "3s", "4s", "5s", "6s", \
    //                      "7s", "8s", "9s", "9s", "9s"};
    // printf ("The number of different tiles he is waiting for is: %d\n", CountWaitingTiles(hand));
    
    return 0;
}